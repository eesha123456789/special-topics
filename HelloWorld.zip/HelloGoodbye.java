public class HelloGoodbye{
    public static void main(String[] args){
        String one= args[0];
        String two =args[1];
        System.out.println ("Hello"+one+"and" +two +".");
        System.out.println ("Goodbye"+two+"and" +one +".");
    }
}